"""
Test suite for Virtual Chip architecture
"""
